function calculateNetWeight() {
    const grossWeight = parseFloat(document.getElementById('grossWeight').value) || 0;
    const tareWeight = parseFloat(document.getElementById('tareWeight').value) || 0;
    const netWeight = grossWeight - tareWeight;
    document.getElementById('netWeight').value = netWeight.toFixed(3);
}

function padRight(text, length) {
    return text + ' '.repeat(Math.max(0, length - text.length));
}

function formatDate(date) {
    if (!date) return '';
    const [year, month, day] = date.split('-');
    return `${day}/${month}/${year}`;
}

function removeTrailingZeros(weight) {
    return parseFloat(weight).toString();
}

function printTicket() {
    const srNo = document.getElementById('srNo').value || '';
    const vehicleNo = document.getElementById('vehicleNo').value || '';
    const vehicleType = document.getElementById('vehicleType').value || '';
    const item = document.getElementById('Item').value || '';
    const partyname = document.getElementById('partyname').value || '';
    const address = document.getElementById('Address').value || '';
    let grossWeight = parseFloat(document.getElementById('grossWeight').value).toFixed(3) || "0.000";
    let tareWeight = parseFloat(document.getElementById('tareWeight').value).toFixed(3) || "0.000";
    let netWeight = (parseFloat(grossWeight) - parseFloat(tareWeight)).toFixed(3);

    grossWeight = removeTrailingZeros(grossWeight);
    tareWeight = removeTrailingZeros(tareWeight);
    netWeight = removeTrailingZeros(netWeight);

    const date1 = formatDate(document.getElementById('date1').value);
    const time1 = document.getElementById('time1').value || '';
    const date2 = formatDate(document.getElementById('date2').value);
    const time2 = document.getElementById('time2').value || '';

    const ticketContent = `
----------------------------------------------------------------------------------
RST. NO.     : ${padRight(srNo, 20)}       Vehicle NO. : ${padRight(vehicleNo, 20)}  
Vhl typ      : ${padRight(vehicleType, 20)}       Party name  : ${padRight(partyname, 20)}
Address      :${padRight(address,25)}   Item        : ${padRight(item, 25)}
----------------------------------------------------------------------------------
Gross :     ${padRight(grossWeight + ' Kg', 15)}Date : ${padRight(date1, 10)}   Time : ${time1}
Tare  :     ${padRight(tareWeight + ' Kg*', 15)}Date : ${padRight(date2, 10)}   Time : ${time2}
Net   :     ${padRight(netWeight + ' Kg', 15)}
----------------------------------------------------------------------------------
                                  
                                  Ph : 123456
                            ! Thanks for your visit !
`;

    const printWindow = window.open('', '_blank', 'width=800,height=600');
    printWindow.document.write(`
        <html>
        <head>
            <style>
                @media print {
                    @page {
                        size: auto;
                        margin: 5mm;
                    }
                    body {
                        margin: 0;
                        padding: 0;
                        font-family: "Lucida Console", Courier, monospace;
                        font-size: 13px;
                        line-height: 1;
                    }
                    h1 {
                        text-align: center;
                        font-weight: bold;
                        font-size: 18px;
                        margin: 0;
                        padding: 0;
                        line-height: 1;
                    }
                    p {
                        text-align: center;
                        font-size: 12px;
                        margin: 0;
                        padding: 0;
                        line-height: 1;
                    }
                    pre {
                        font-size: 14px;
                        white-space: pre-wrap;
                    }
                }
            </style>
        </head>
        <body>
            <h1>M/S SANTOSH CONSTRUCTION</h1>
            <p>CHANDWA, LATEHAR</p>
            <p>High City, 654 321 (Raj)</p>
            <br>
            <pre>${ticketContent}</pre>
        </body>
        </html>
    `);
    printWindow.document.close();
    printWindow.print();
}

// Additional JavaScript to increase lines
function logDetails() {
    console.log("Printing ticket details...");
}

function validateInput(inputId) {
    const input = document.getElementById(inputId);
    if (!input.value) {
        console.log(`${inputId} is empty.`);
    }
}

function resetForm() {
    document.querySelectorAll('input').forEach(input => input.value = '');
    console.log("Form has been reset.");
}

function dummyLoop() {
    for (let i = 0; i < 300; i++) {
        console.log(`Log Entry ${i}`);
    }
}

dummyLoop();

setTimeout(() => {
    console.log("Timeout triggered!");
}, 5000);

let counter = 0;
while (counter < 200) {
    console.log(`Counter: ${counter}`);
    counter++;
}

const logArray = Array.from({ length: 150 }, (_, i) => `Array Log ${i}`);
logArray.forEach(log => console.log(log));
